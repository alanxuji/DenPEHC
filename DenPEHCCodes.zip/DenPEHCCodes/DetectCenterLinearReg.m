
function centersCntReg=DetectCenterLinearReg(gammaSort,LocalR,GlobalR,FitLen)
Len=min(50,length(gammaSort));

SortedGammaFront=gammaSort(1:Len);
AllMaxDiff=max(-diff(SortedGammaFront)); %��-��is very important decause the definition of diff is the latter minus former
for i=Len-FitLen:-1:2
   currentVector=SortedGammaFront(i:i+FitLen);
    a=polyfit(i:i+FitLen,currentVector,1);
    gammaPredict=polyval(a,i-1);
   MaxDiff=max(-diff(currentVector));
   CurrentDiff=SortedGammaFront(i-1)-gammaPredict;
    if CurrentDiff>LocalR*MaxDiff && CurrentDiff>GlobalR*AllMaxDiff
        break;
    end
end
centersCntReg=i-1;