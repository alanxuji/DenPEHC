function DistanceMat=PairDotsDistance(Dots,NDim, numOfDots)
Len=numOfDots*(numOfDots-1)/2;
DistanceMat=zeros(3,Len);

%

matIndex=1;
for i=1:numOfDots-1
    for j=i+1:numOfDots
     DistanceMat(1,matIndex)=i; 
     DistanceMat(2,matIndex)=j;
     %% Euclidian Distance
% %     Sqd=0;
% %      for k=1:NDim
% %        Sqd=Sqd+(Dots(k,i)-Dots(k,j))^2;
% %      end
% %      DistanceMat(3,matIndex)=sqrt(Sqd);
 DistanceMat(3,matIndex)=sqrt(sum((Dots(:,i)-Dots(:,j)).^2));
%% Cosine Distance      
% A=(Dots(:,i))';
% B=(Dots(:,j))';
% Anorm=sqrt(sum(A.*A));
% Bnorm=sqrt(sum(B.*B));
% D=sum(A.*B);
% DistanceMat(3,matIndex)=1-D/(Anorm*Bnorm);
%% DistanceMat(3,matIndex)=pdist2(A,B,'cosine');
    matIndex=matIndex+1;
    end
 % fprintf('i=%d\n',i);
end
end