%% ARI implementation 
% Paper L. Hubert and P. Arabie, ��Comparing Partitions,�� J. Classification,vol. 2, no. 1, pp. 193-218, 1985.

% Input:U��V�� =��DataID, ClusterID����DataID must in the same order!
yy=load('EcoliMR-1');
xx=load('data\\EcoliNoLabel1.csv');

 [m,n]=size(xx);
U=zeros(m,2);
U(:,1)=xx(:,1);
U(:,2)=xx(:,2);

ObjectNum=m;
ClusNU=max(U(:,2));

V=zeros(m,2);
V(:,1)=1:m;
V(:,2)=yy(:,2);

% %for legclust evaluation
% % V=zeros(214,2);
% % V(:,1)=1:214;
% % V(:,2)=(class_rs(11,:))';
% 
% 
ClusNV=max(V(:,2));

%construct contegency table Mat
CT=zeros(ClusNU,ClusNV);
for i=1:ClusNU
    for j=1:ClusNV        
        CT(i,j)=length(intersect(find(U(:,2)==i),find(V(:,2)==j)));
    end
end
%Check for correctness of CT
% U8=find(U(:,2)==8);
% V3=find(V(:,2)==3);
% UV83=intersect(U8,V3);

%% ai,bj,
for  i=1:ClusNU
a(i)=sum(CT(i,:));
end
for  j=1:ClusNV
b(j)=sum(CT(:,j));
end
CTC2=sum(sum(CT.*(CT-1)./2));%��÷��ӵ�һ���֣�C2�������
NC2=ObjectNum*(ObjectNum-1)/2;
AC2=sum(a.*(a-1)./2);
BC2=sum(b.*(b-1)./2);
ARI=(CTC2-AC2*BC2/NC2)/((AC2+BC2)/2-AC2*BC2/NC2);

