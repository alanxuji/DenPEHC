%% NMI implementation 
% Paper: Vinh, Nguyen Xuan, Julien Epps, and James Bailey. "Information theoretic measures for clusterings comparison: Variants, properties, normalization and correction for chance." The Journal of Machine Learning Research 11 (2010): 2837-2854.
% Input:U��V�� =��DataID, ClusterID����DataID must in the same order!
yy=load('EcoliMR-1');
xx=load('data\\EcoliNoLabel1.csv');

[m1,n1]=size(xx);
U=zeros(m1,2);
U(:,1)=1:m1;
U(:,2)=xx(:,2);%%Attention��

[m,n]=size(U);
ObjectNum=m;
ClusNU=max(U(:,2));

 V=zeros(m,2);
V(:,1)=1:m;
V(:,2)=yy(:,2);

%for legclust evaluation
% V=zeros(214,2);
% V(:,1)=1:214;
% V(:,2)=(class_rs(11,:))';

ClusNV=max(V(:,2));

%construct contegency table Mat
CT=zeros(ClusNU,ClusNV);
for i=1:ClusNU
    for j=1:ClusNV        
        CT(i,j)=length(intersect(find(U(:,2)==i),find(V(:,2)==j)));
    end
end
%Check for correctness of CT
% U8=find(U(:,2)==8);
% V3=find(V(:,2)==3);
% UV83=intersect(U8,V3);

%% ai,bj,
for  i=1:ClusNU
a(i)=sum(CT(i,:));
end
for  j=1:ClusNV
b(j)=sum(CT(:,j));
end
% La=log(a);
aP=a./ObjectNum;
HU=-(sum(aP.*log(aP)));
bP=b./ObjectNum;
HV=-(sum(bP.*log(bP)));
NP=CT/ObjectNum;

for i=1:ClusNU
    for j=1:ClusNV
        % dealing with 0log0
        if NP(i,j)==0
          ICT(i,j)=0;
          continue;
        end
        ICT(i,j)=NP(i,j)*log(NP(i,j)/aP(i)/bP(j));
    end
end
IUV=sum(sum(ICT));
NMI=IUV/sqrt(HU*HV);

MPurity=MetaPurity(U(:,2),V(:,2));

